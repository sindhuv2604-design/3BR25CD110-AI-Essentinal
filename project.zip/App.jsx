import { useState } from 'react';

function App() {
  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [about, setAbout] = useState("");
  const [skills, setSkills] = useState("");
  const [projects, setProjects] = useState("");

  const inputStyle = {
    width: '100%',
    padding: '10px',
    marginBottom: '12px',
    borderRadius: '6px',
    border: '1px solid #475569',
    backgroundColor: '#0f172a',
    color: '#f8fafc',
    fontSize: '0.85rem',
    boxSizing: 'border-box'
  };

  return (
    <div style={{
      fontFamily: 'system-ui, -apple-system, sans-serif',
      backgroundColor: '#f8fafc',
      minHeight: '100vh',
      padding: '0 0 2rem 0',
      color: '#1e293b',
      lineHeight: '1.6'
    }}>
      {/* Top Main Banner Header */}
      <header style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #334155 100%)',
        color: '#ffffff',
        padding: '3rem 1.5rem',
        textAlign: 'center',
        marginBottom: '2rem',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
      }}>
        <h1 style={{ margin: 0, fontSize: '2.5rem', fontWeight: 700, letterSpacing: '-0.025em' }}>
          Interactive Portfolio Generator
        </h1>
        <p style={{ margin: '0.75rem 0 0', color: '#94a3b8', fontSize: '1.1rem' }}>
          Fill out your information on the left to preview your live portfolio on the right.
        </p>
      </header>

      {/* Main Content Area */}
      <div style={{
        maxWidth: '1100px',
        margin: '0 auto',
        padding: '0 1rem'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '2rem'
        }}>
          {/* Form Input Panel */}
          <div style={{
            backgroundColor: '#1e293b',
            color: '#ffffff',
            padding: '1.5rem',
            borderRadius: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{ marginTop: 0, fontSize: '1.25rem', borderBottom: '1px solid #334155', paddingBottom: '0.5rem', color: '#38bdf8' }}>
              Enter Your Details
            </h2>

            <label style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Full Name</label>
            <input
              type="text"
              placeholder="e.g. John Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={inputStyle}
            />

            <label style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Title / Role</label>
            <input
              type="text"
              placeholder="e.g. Full Stack Developer"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              style={inputStyle}
            />

            <label style={{ fontSize: '0.8rem', color: '#94a3b8' }}>About You</label>
            <textarea
              placeholder="Brief summary about yourself..."
              value={about}
              onChange={(e) => setAbout(e.target.value)}
              style={{ ...inputStyle, minHeight: '80px', resize: 'vertical' }}
            />

            <label style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Skills (comma separated)</label>
            <input
              type="text"
              placeholder="e.g. React, Python, C++, Node.js"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              style={inputStyle}
            />

            <label style={{ fontSize: '0.8rem', color: '#94a3b8' }}>Featured Projects</label>
            <textarea
              placeholder="Describe key projects..."
              value={projects}
              onChange={(e) => setProjects(e.target.value)}
              style={{ ...inputStyle, minHeight: '80px', resize: 'vertical' }}
            />
          </div>

          {/* Live Preview Panel */}
          <div style={{
            backgroundColor: '#ffffff',
            padding: '1.5rem',
            borderRadius: '12px',
            boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
            border: '1px solid #e2e8f0'
          }}>
            <h2 style={{ marginTop: 0, fontSize: '1.25rem', borderBottom: '1px solid #e2e8f0', paddingBottom: '0.5rem', color: '#0f172a' }}>
              Live Portfolio Preview
            </h2>

            <div style={{
              backgroundColor: '#f8fafc',
              padding: '1.5rem',
              borderRadius: '8px',
              border: '1px solid #f1f5f9'
            }}>
              <h3 style={{ margin: '0 0 0.25rem', color: '#0f172a', fontSize: '1.5rem' }}>
                {name || 'Your Name'}
              </h3>
              <p style={{ margin: '0 0 1rem', color: '#0284c7', fontWeight: 600 }}>
                {role || 'Your Role / Title'}
              </p>

              <hr style={{ border: 'none', borderTop: '1px solid #e2e8f0', margin: '1rem 0' }} />

              <h4 style={{ margin: '0 0 0.5rem', color: '#334155' }}>About</h4>
              <p style={{ margin: '0 0 1rem', color: '#64748b', fontSize: '0.9rem' }}>
                {about || 'Your bio will appear here as you type...'}
              </p>

              <h4 style={{ margin: '0 0 0.5rem', color: '#334155' }}>Skills</h4>
              <p style={{ margin: '0 0 1rem', color: '#64748b', fontSize: '0.9rem' }}>
                {skills || 'Listed skills will display here...'}
              </p>

              <h4 style={{ margin: '0 0 0.5rem', color: '#334155' }}>Projects</h4>
              <p style={{ margin: 0, color: '#64748b', fontSize: '0.9rem' }}>
                {projects || 'Project details will show here...'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
